<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tambah Data Siswa</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body style="background: lightgray">

    <div class="container mt-5 mb-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <form action="<?php echo e(route('siswa.store')); ?>" method="POST" enctype="multipart/form-data">
                        
                            <?php echo csrf_field(); ?>
                            
                                <!-- error message untuk title -->

                            <div class="form-group">
                                <label class="font-weight-bold">Nama</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama" value="<?php echo e(old('nama')); ?>" placeholder="Masukkan Nama">
                            
                                <!-- error message untuk title -->
                                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">

                            <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="form-group">
                                <label for="exampleDropdown" class="font-weight-bold">KELAS</label>
                                <select name="kelas" class="form-control" id="exampleDropdown">
                                    <option value="X TK">X - TK</option>
                                    <option value="XI TK">XI - TK</option>
                                    <option value="XII TK">XII - TK</option>
                                    <option value="X TE">X - TE</option>
                                    <option value="XI TE">XI - TE</option>
                                    <option value="XII TE">XII - TE</option>
                                    <option value="X TM">X - TM </option>
                                    <option value="XI TM">XI - TM </option>
                                    <option value="XII TM">XII - TM </option>
                                    <option value="X TO">X - TO </option>
                                    <option value="XI TO">XI - TO </option>
                                    <option value="XII TO">XII - TO </option>
                                    <option value="X TKJ">X - TKJ </option>
                                    <option value="XI TKJ">XI - TKJ </option>
                                    <option value="XII TKJ">XII - TKJ </option>
                                    <option value="X PPLG">X - PPLG</option>
                                    <option value="XI PPLG">XI - PPLG</option>
                                    <option value="XII PPLG">XII - PPLG</option>
                                    <option value="X BP">X - BP </option>
                                    <option value="XI BP">XI - BP </option>
                                    <option value="XII BP">XII - BP </option>
                                    <option value="X MM">X - MM </option>
                                    <option value="XI MM">XI - MM </option>
                                    <option value="XII MM">XII - MM </option>
                                    <option value="X BB">X - BB </option>
                                    <option value="XI BB">XI - BB </option>
                                    <option value="XII BB">XII - BB </option>
                                  </select>
                                
                            
                                <!-- error message untuk content -->
                                <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>
                            <button type="reset" class="btn btn-md btn-warning">RESET</button>

                        </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace( 'text' );
</script>
</body>
</html><?php /**PATH C:\laragon\www\pkl\resources\views/siswa/create.blade.php ENDPATH**/ ?>